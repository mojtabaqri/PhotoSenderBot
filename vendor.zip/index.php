<?php

echo 'w';